package co.ke.bluestron.bsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BsapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
