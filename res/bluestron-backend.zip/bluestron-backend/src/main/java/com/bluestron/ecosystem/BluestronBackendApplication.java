package com.bluestron.ecosystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BluestronBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BluestronBackendApplication.class, args);
	}

}
