package com.bluestron.ecosystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BluestronBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
